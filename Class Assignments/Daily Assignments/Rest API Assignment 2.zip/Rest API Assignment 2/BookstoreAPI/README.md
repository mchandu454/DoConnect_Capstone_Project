# Bookstore API

This is my RESTful API project for the online book store assignment using ASP.NET Core.

## Features Implemented
- Created the API to handle full CRUD operations for Books and Authors.
- Used an Entity Framework in-memory database to store the data so it runs easily without extra setup.
- Added basic data validation to make sure required fields like the book title are provided. It throws a 400 Bad Request error if anything is missing.
- Set up associations and attribute routing so everything connects properly.

## Endpoints
I implemented the standard HTTP methods for the entities:
- `GET /api/books` - Gets a list of all books
- `GET /api/books/{id}` - Gets a specific book
- `POST /api/books` - Creates a new book
- `PUT /api/books/{id}` - Updates a book
- `DELETE /api/books/{id}` - Deletes a book

The same structure applies to Authors using `/api/authors`.
I also set up a custom route: `GET /api/authors/{authorId}/books` to get all the books linked to a specific author.

## Testing with Postman
I included a `postman_collection.json` file in the folder. It has all the requests saved inside, so the API endpoints and the JSON bodies are already set up to verify the CRUD functionality, relationships, and edge cases. We can run these to confirm everything works as expected.

## Debugging with Fiddler
I tested and debugged the API using Fiddler to monitor the HTTP traffic. Since the API runs locally, I used Postman alongside Fiddler to check the requests. Everything returns the expected JSON data format and correct status codes like 200 OK, 201 Created, and 404 Not Found depending on the request.
