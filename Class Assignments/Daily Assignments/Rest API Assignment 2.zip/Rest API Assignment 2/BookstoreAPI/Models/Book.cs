using System.ComponentModel.DataAnnotations;

namespace BookstoreAPI.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Book title is required.")]
        [StringLength(200, ErrorMessage = "Book title cannot exceed 200 characters.")]
        public string Title { get; set; } = string.Empty;

        [Range(1000, 2100, ErrorMessage = "Please enter a valid publication year.")]
        public int? PublicationYear { get; set; }

        [Required(ErrorMessage = "An author must be assigned to the book.")]
        public int AuthorId { get; set; }

        public Author? Author { get; set; }
    }
}
