﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrinciplesDemo.Models
{
    public class FinancialReport : Report
    {
        public override void Generate()
        {
            Console.WriteLine("Generating Financial Report");
        }
    }
}
