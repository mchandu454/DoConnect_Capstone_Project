﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolidPrinciplesDemo.Models;

namespace SolidPrinciplesDemo.Savers
{
    public class ReportSaver
    {
        public void SaveToFile(Report report)
        {
            Console.WriteLine($"Saving report: {report.Title}");
        }
    }
}