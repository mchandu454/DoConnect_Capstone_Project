﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolidPrinciplesDemo.Interfaces;
using SolidPrinciplesDemo.Models;

namespace SolidPrinciplesDemo.Formatters
{
    public class PdfFormatter : IReportFormatter
    {
        public void Format(Report report)
        {
            Console.WriteLine("Formatting report as PDF");
        }
    }
}
