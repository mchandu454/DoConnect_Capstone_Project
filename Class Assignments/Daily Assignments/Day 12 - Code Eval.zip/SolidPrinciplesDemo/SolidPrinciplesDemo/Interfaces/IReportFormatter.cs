﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolidPrinciplesDemo.Models;

namespace SolidPrinciplesDemo.Interfaces
{
    public interface IReportFormatter
    {
        void Format(Report report);
    }
}
