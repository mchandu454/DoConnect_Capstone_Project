﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SolidPrinciplesDemo.Models;

namespace SolidPrinciplesDemo.Generators
{
    public class ReportGenerator
    {
        public Report GenerateReport(string title)
        {
            return new Report
            {
                Title = title,
                Content = "Report Content"
            };
        }
    }
}
